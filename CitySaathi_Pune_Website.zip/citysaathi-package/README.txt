CitySaathi Pune — Website Prototype

HOW TO RUN
1. Extract this ZIP file.
2. Open index.html in a modern browser (Chrome, Edge, Firefox).
3. An internet connection is recommended for externally hosted images and Google Maps links.

INCLUDED FUNCTIONALITY
- Place search and category/budget filters using bundled sample data
- Place detail dialogs and Google Maps search links
- Favourite places saved in browser localStorage
- Sample itinerary generation and local plan saving
- Community observations saved locally in the browser
- Responsive layout

IMPORTANT LIMITATIONS
This is a front-end prototype. It does not include a server/backend, login, shared cloud storage, live place/weather/routing API connections, or production verification of opening hours/prices. Favourites, plans and community notes are stored only in the current browser/device. No API keys are included.

To run a local development server (optional):
  python -m http.server 8000
Then open http://localhost:8000
